#!/usr/bin/env python

__author__ = 'Piotr.Malczak@gpm-sys.com'

gnu_description_pattern = '^\$.* \|(PD\w*)\| (\d*)pp @(.*)@ (.*) \| %(.*)% .*$'  # (PD) (pp) (customer) (desc)
